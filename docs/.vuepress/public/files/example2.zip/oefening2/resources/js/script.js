window.addEventListener('DOMContentLoaded', getData);

async function getData() {
    document.getElementById('result').style.display = "block";
    let response = await fetch("/resources/data/apisim.json");
    let json = await response.json();
    console.log(json);

    let inputValues = Object.values(json.Data);
    console.log(inputValues);

    let tbody = document.getElementById("tableBody");
    while (tbody.hasChildNodes()) {
        tbody.removeChild(tbody.firstChild);
    }

    inputValues.forEach((data) => {
        let row = tbody.insertRow(-1);
        let cell = row.insertCell(-1);
        let date = document.createTextNode(data.Date);
        cell.appendChild(date);
        cell = row.insertCell(-1);
        let temp = document.createTextNode(data.Temp);
        cell.appendChild(temp);
        cell = row.insertCell(-1);
        let humi = document.createTextNode(data.Humi);
        cell.appendChild(humi);
        cell = row.insertCell(-1);
        let co2 = document.createTextNode(data.Co2);
        cell.appendChild(co2);
    });

    google.charts.load('current', { 'packages': ['line'] });
    google.charts.setOnLoadCallback(function () {
        // create data columns
        var data = new google.visualization.DataTable();
        data.addColumn('date', 'Date');
        data.addColumn('number', 'Temp');
        data.addColumn('number', 'Humi');
        data.addColumn('number', 'Co2');
        // add the data in rows by iterating through the values
        inputValues.forEach((dataRecord) => {
            data.addRow([new Date(dataRecord.Date), parseFloat(dataRecord.Temp), parseFloat(dataRecord.Humi), parseFloat(dataRecord.Co2)]);
        });
        // set the graph options
        var options = {
            chart: { title: 'History graph', },
            width: '100%',
            height: 690,
            series: { 0: { axis: 'Data' } },
            hAxis: { format: 'd/M/yy', gridlines: {count: 15} },
            axes: {  y: {
                temp: { label: 'Temp (°C)' },
                humi: { label: 'Humi (%)'},
                co2: {label: 'co2 (ppm)'} } },
            legend: { position: 'none' }
        };
        // instantiate and draw our chart, passing in the options.
        var chart = new google.charts.Line(document.getElementById('chart'));
        chart.draw(data, google.charts.Line.convertOptions(options));
    });     
};